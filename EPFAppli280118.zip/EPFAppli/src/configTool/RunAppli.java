package configTool;

import modelDesigner.Mortality;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

public class RunAppli {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try {
			RConnection c = new RConnection();
		} catch (RserveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Mortality mort = new Mortality();
		
		System.out.println(mort.title);

	}

}
