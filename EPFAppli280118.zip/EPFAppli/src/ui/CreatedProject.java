package ui;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import rate.wizards.MainPageWizardPage;
import org.eclipse.wb.swt.SWTResourceManager;

public class CreatedProject extends Dialog {

	protected Object result;
	protected Shell shlNewEpfaProjet;
	private Text txtTextprojetname;
	private Text textSpeciesName;
	private Text textAuthor;
	private Text textDate;
	private Text textObservation;
	private Text textProjectLocation;
	
	
	File fileP;
	String strPathProject;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public CreatedProject(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shlNewEpfaProjet.open();
		shlNewEpfaProjet.layout();
		Display display = getParent().getDisplay();
		while (!shlNewEpfaProjet.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shlNewEpfaProjet = new Shell(getParent(), SWT.DIALOG_TRIM);
		shlNewEpfaProjet.setSize(451, 346);
		shlNewEpfaProjet.setText("New EPFA Project");
		shlNewEpfaProjet.setLayout(new FormLayout());
		
		Group grpProjectInfo = new Group(shlNewEpfaProjet, SWT.NONE);
		grpProjectInfo.setText("Project Info");
		GridLayout gl_grpProjectInfo = new GridLayout(2, false);
		gl_grpProjectInfo.horizontalSpacing = 6;
		gl_grpProjectInfo.verticalSpacing = 7;
		grpProjectInfo.setLayout(gl_grpProjectInfo);
		FormData fd_grpProjectInfo = new FormData();
		fd_grpProjectInfo.top = new FormAttachment(0, 10);
		fd_grpProjectInfo.left = new FormAttachment(0);
		fd_grpProjectInfo.right = new FormAttachment(100);
		grpProjectInfo.setLayoutData(fd_grpProjectInfo);
		
		Label lblProjectName = new Label(grpProjectInfo, SWT.NONE);
		lblProjectName.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		lblProjectName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblProjectName.setText("Project Name(*) : ");
		
		txtTextprojetname = new Text(grpProjectInfo, SWT.BORDER);
		txtTextprojetname.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblSpeciesfungiName = new Label(grpProjectInfo, SWT.NONE);
		lblSpeciesfungiName.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		lblSpeciesfungiName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblSpeciesfungiName.setText("Species(Fungi) Name(*) :");
		
		textSpeciesName = new Text(grpProjectInfo, SWT.BORDER);
		textSpeciesName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblAuthor = new Label(grpProjectInfo, SWT.NONE);
		lblAuthor.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		lblAuthor.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblAuthor.setText("Author :");
		
		textAuthor = new Text(grpProjectInfo, SWT.BORDER);
		textAuthor.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblDate = new Label(grpProjectInfo, SWT.NONE);
		lblDate.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		lblDate.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblDate.setText("Date : ");
		
		textDate = new Text(grpProjectInfo, SWT.BORDER);
		textDate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		textDate.setText(dateFormat.format(date));

		
		Label lblObservation = new Label(grpProjectInfo, SWT.NONE);
		lblObservation.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		lblObservation.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblObservation.setText("Observation : ");
		
		textObservation = new Text(grpProjectInfo, SWT.BORDER);
		textObservation.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Composite composite = new Composite(shlNewEpfaProjet, SWT.NONE);
		fd_grpProjectInfo.bottom = new FormAttachment(100, -61);
		
		Button btnLocation = new Button(grpProjectInfo, SWT.NONE);
		btnLocation.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD | SWT.ITALIC));
		GridData gd_btnLocation = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		gd_btnLocation.widthHint = 130;
		btnLocation.setLayoutData(gd_btnLocation);
		btnLocation.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				DirectoryDialog dialogTmax = new DirectoryDialog(shlNewEpfaProjet);
				
				dialogTmax.setText("Max Temperature");
				dialogTmax.setMessage("Select the Location of the project");
				
				String pathDir = dialogTmax.open();
				
				if(pathDir !=null)
				{
					textProjectLocation.setText(pathDir);
					
				}
			}
		});
		btnLocation.setText("Location(*) ... ");
		
		textProjectLocation = new Text(grpProjectInfo, SWT.BORDER);
		textProjectLocation.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		FormData fd_composite = new FormData();
		fd_composite.left = new FormAttachment(grpProjectInfo, 0, SWT.LEFT);
		fd_composite.top = new FormAttachment(grpProjectInfo, 6);
		fd_composite.bottom = new FormAttachment(100, -10);
		fd_composite.right = new FormAttachment(100);
		composite.setLayoutData(fd_composite);
		
		Button btnCancel = new Button(composite, SWT.NONE);
		btnCancel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				shlNewEpfaProjet.dispose();
			}
		});
		btnCancel.setBounds(341, 10, 84, 25);
		btnCancel.setText("Cancel");
		
		Button btnFinish = new Button(composite, SWT.NONE);
		btnFinish.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if(txtTextprojetname.getText().equalsIgnoreCase(""))
				{
	    			MessageDialog.openError(shlNewEpfaProjet, "Error", "You must enter the name of the project");
	    			return;
	    		}
				
				if(textSpeciesName.getText().equalsIgnoreCase(""))
				{
	    			MessageDialog.openError(shlNewEpfaProjet, "Error", "You must enter the name of the fungi studied!");
	    			return;
	    		}
				
				if(textProjectLocation.getText().equalsIgnoreCase(""))
				{
	    			MessageDialog.openError(shlNewEpfaProjet, "Error", "Please Specify the location of the project!");
	    			return;
	    		}
				if(createProject())
				{
					MessageDialog.openInformation(new Shell(), "New EPFAProject", "Project created successfully");
					shlNewEpfaProjet.dispose();
				}
					
				else
					MessageDialog.openInformation(new Shell(), "New Project", "problem when trying to created the project");

			}
		});
		btnFinish.setBounds(240, 10, 90, 25);
		btnFinish.setText("Finish");

	}
	
	
	private boolean createProject() {
		strPathProject = textProjectLocation.getText();
		fileP = new File(strPathProject + File.separator + txtTextprojetname.getText().trim());
		if(!fileP.exists()){
			fileP.mkdir();
			//BufferedWriter bw;
			File fileMortalityPath = new File(fileP + File.separator + "Mortality");
			fileMortalityPath.mkdir();
			new File(fileP + File.separator + "Mapping").mkdir();
			
			String stg =new String(fileMortalityPath.getAbsolutePath().replace('\\', '/'));
			MainPageWizardPage.setStrMortalityPath(stg);
			System.out.println(MainPageWizardPage.getstrMortalityPath());
		}
		return true;
	}
	
	private void crateFolders()
	{
		
		new File(fileP + File.separator + "Mortality").mkdir();
		new File(fileP + File.separator + "Mapping").mkdir();
		
	}
	
}
