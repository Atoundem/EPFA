package ui;

import java.io.File;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;

import rate.wizards.DevRateWizardDialog;
import ui.mapping.MappingDialog;
import ui.modeling.LoadPlotData;
//import ui.modeling.MainPageWizardPage;
import ui.modeling.MortalityWizardDialog;

import rate.wizards.MainPageWizardPage;


public class EPF {

	protected Shell shlEpfSoftware;
	private static RConnection c;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			c = new RConnection();
			
			
		
            
            c.close(); //for test
            EPF window = new EPF();
			window.open();
		} catch (Exception e) {
			MessageDialog.openError(new Shell(), "Error", "Verify that Rserve is running before launching the application");
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlEpfSoftware.open();
		shlEpfSoftware.layout();
		while (!shlEpfSoftware.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlEpfSoftware = new Shell();
		shlEpfSoftware.setToolTipText("Model EPF virulence\r\n");
		shlEpfSoftware.setSize(934, 532);
		shlEpfSoftware.setText("EPFA Software");
		
		Menu mainMenubar = new Menu(shlEpfSoftware, SWT.BAR);
		shlEpfSoftware.setMenuBar(mainMenubar);
		
		MenuItem mntmFile = new MenuItem(mainMenubar, SWT.CASCADE);
		mntmFile.setText("File");
		
		Menu menu = new Menu(mntmFile);
		mntmFile.setMenu(menu);
		
		MenuItem mntmNew = new MenuItem(menu, SWT.CASCADE);
		mntmNew.setText("New");
		
		Menu menu_6 = new Menu(mntmNew);
		mntmNew.setMenu(menu_6);
		
		MenuItem mntmEpfProject = new MenuItem(menu_6, SWT.PUSH);
		mntmEpfProject.setText("EPF Project");
		
		mntmEpfProject.addSelectionListener(new OpenProject());
		
		new MenuItem(menu, SWT.SEPARATOR);
		
		MenuItem mntmOpen = new MenuItem(menu, SWT.NONE);
		mntmOpen.setText("Close");
		
		MenuItem mntmItem = new MenuItem(menu, SWT.NONE);
		mntmItem.setText("Close All\r\n");
		
		new MenuItem(menu, SWT.SEPARATOR);
		
		MenuItem mntmSave = new MenuItem(menu, SWT.NONE);
		mntmSave.setText("Save");
		
		MenuItem mntmSaveAll = new MenuItem(menu, SWT.NONE);
		mntmSaveAll.setText("Save All");
		
		new MenuItem(menu, SWT.SEPARATOR);
		
		MenuItem mntmProperties = new MenuItem(menu, SWT.NONE);
		mntmProperties.setText("Properties");
		
		new MenuItem(menu, SWT.SEPARATOR);
		
		MenuItem mntmExit = new MenuItem(menu, SWT.RADIO);
		mntmExit.setText("Exit");
		
		MenuItem mntmEdit = new MenuItem(mainMenubar, SWT.CASCADE);
		mntmEdit.setText("Edit");
		
		Menu menu_1 = new Menu(mntmEdit);
		mntmEdit.setMenu(menu_1);
		
		MenuItem mntmCopy = new MenuItem(menu_1, SWT.NONE);
		mntmCopy.setText("Undo");
		
		MenuItem mntmNewItem = new MenuItem(menu_1, SWT.NONE);
		mntmNewItem.setText("Redo");
		
		new MenuItem(menu_1, SWT.SEPARATOR);
		
		MenuItem mntmCut = new MenuItem(menu_1, SWT.NONE);
		mntmCut.setText("Cut");
		
		MenuItem mntmCopy_1 = new MenuItem(menu_1, SWT.NONE);
		mntmCopy_1.setText("Copy");
		
		MenuItem mntmPaste = new MenuItem(menu_1, SWT.NONE);
		mntmPaste.setText("Paste");
		
		new MenuItem(menu_1, SWT.SEPARATOR);
		
		MenuItem mntmDelete = new MenuItem(menu_1, SWT.NONE);
		mntmDelete.setText("Delete");
		
		MenuItem mntmSelectAll = new MenuItem(menu_1, SWT.NONE);
		mntmSelectAll.setText("Select All");
		
		MenuItem mntmTask = new MenuItem(mainMenubar, SWT.CASCADE);
		mntmTask.setText("Task");
		
		Menu menu_2 = new Menu(mntmTask);
		mntmTask.setMenu(menu_2);
		
		MenuItem mntmMotalityDesigner = new MenuItem(menu_2, SWT.CASCADE);
		mntmMotalityDesigner.setText("Motality Designer");
		
		Menu menu_3 = new Menu(mntmMotalityDesigner);
		mntmMotalityDesigner.setMenu(menu_3);
		
		MenuItem mntmLoadAndPlot = new MenuItem(menu_3, SWT.NONE);
		mntmLoadAndPlot.setText("Load and Plot Data");
		
		MenuItem mntmMortalityModel = new MenuItem(menu_3, SWT.NONE);
		mntmMortalityModel.setText("Mortality Model");
		
		MenuItem mntmMapping = new MenuItem(menu_2, SWT.NONE);
		mntmMapping.setText("Mapping");
		
		MenuItem mntmEpfAutidispersion = new MenuItem(menu_2, SWT.NONE);
		mntmEpfAutidispersion.setText("EPF Auti-dispersion");
		
		MenuItem mntmWindows = new MenuItem(mainMenubar, SWT.CASCADE);
		mntmWindows.setText("Windows");
		
		Menu menu_4 = new Menu(mntmWindows);
		mntmWindows.setMenu(menu_4);
		
		MenuItem mntmHelp = new MenuItem(mainMenubar, SWT.CASCADE);
		mntmHelp.setText("Help ?");
		
		Menu menu_5 = new Menu(mntmHelp);
		mntmHelp.setMenu(menu_5);
		
		MenuItem mntmDocumentation = new MenuItem(menu_5, SWT.NONE);
		mntmDocumentation.setText("User Manual");
		
		new MenuItem(menu_5, SWT.SEPARATOR);
		
		MenuItem mntmAboutSoftware = new MenuItem(menu_5, SWT.NONE);
		mntmAboutSoftware.setText("About EPFA");
		
		ToolBar toolBar = new ToolBar(shlEpfSoftware, SWT.FLAT | SWT.RIGHT);
		toolBar.setToolTipText("Mapping EPF efficacy zone");
		toolBar.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		toolBar.setBounds(0, 0, 908, 30);
		
		ToolItem toolItemPlotData = new ToolItem(toolBar, SWT.PUSH);
		toolItemPlotData.setText("Plot Data");
		toolItemPlotData.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				
				System.out.println(MainPageWizardPage.getstrMortalityPath());
				if(MainPageWizardPage.getstrMortalityPath().equalsIgnoreCase("/"))
				{
	    			MessageDialog.openError(shlEpfSoftware, "Notification", "You must first created a new project before start simulation");
	    			//shellPlotData.dispose();
	    		}
				else
				{
					LoadPlotData fenetreFille = new LoadPlotData(shlEpfSoftware,SWT.SHELL_TRIM);
					//fenetreFille.setSize(200, 200);
					fenetreFille.open();
					
				}
				
				
			}
		});
		toolItemPlotData.setWidth(26);
		toolItemPlotData.setImage(SWTResourceManager.getImage(EPF.class, "/Img/PlotDataIcon.png"));
		toolItemPlotData.setToolTipText("Load and Plot Data");
	
		ToolItem toolItem = new ToolItem(toolBar, SWT.SEPARATOR);
/*		
		ToolItem toolItemModelBuilder = new ToolItem(toolBar, SWT.PUSH);
		toolItemModelBuilder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				 //shlEpfSoftware
				WizardDialog dialog = new WizardDialog(shlEpfSoftware, new MortalityWizardDialog());
				dialog.create();
				  dialog.setBlockOnOpen(true);
				  dialog.open();
			}
		});
		toolItemModelBuilder.setImage(SWTResourceManager.getImage(EPF.class, "/Img/MortalityIcon.png"));
	
	*/
		ToolItem tltmMapping = new ToolItem(toolBar, SWT.NONE);
		tltmMapping.setText("Mapping");
		tltmMapping.setToolTipText("Mapping of Zone of efficacy");
		tltmMapping.setImage(SWTResourceManager.getImage(EPF.class, "/Img/MappingIcon.png"));
		
		ToolItem tltmModel = new ToolItem(toolBar, SWT.NONE);
		tltmModel.setToolTipText("Virulence model");
		tltmModel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				
				WizardDialog dialog = new WizardDialog(shlEpfSoftware, new DevRateWizardDialog());
				dialog.create();
				  dialog.setBlockOnOpen(true);
				  dialog.open();
			}
		});
		tltmModel.setImage(SWTResourceManager.getImage(EPF.class, "/Img/MortalityIcon.png"));
		tltmModel.setText("Model Builder");
		
		tltmMapping.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				MappingDialog mapWing = new MappingDialog(shlEpfSoftware,SWT.SHELL_TRIM);
				//fenetreFille.setSize(200, 200);
				mapWing.open();
			}
		});
		
		Label label = new Label(shlEpfSoftware, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(13, -2, 64, 2);
		
		Label label_1 = new Label(shlEpfSoftware, SWT.SEPARATOR | SWT.VERTICAL);
		label_1.setBounds(81, 0, -3, 30);
		
		Label label_2 = new Label(shlEpfSoftware, SWT.SEPARATOR | SWT.VERTICAL);
		label_2.setBounds(75, -35, 2, 64);
		
		Label label_3 = new Label(shlEpfSoftware, SWT.SEPARATOR | SWT.VERTICAL);
		label_3.setBounds(116, 0, 0, 30);

	}
	
	class OpenProject implements SelectionListener {
	    public void widgetSelected(SelectionEvent event) {
	    	CreatedProject newProject = new CreatedProject(shlEpfSoftware, SWT.SHELL_TRIM);
	    	newProject.open();
	    }

		@Override
		public void widgetDefaultSelected(SelectionEvent arg0) {
			// TODO Auto-generated method stub
			
		}
	}

	public static RConnection getConnection() {
		return c;
	}

	public static void setConnection(RConnection c) {
		EPF.c = c;
	}
}
