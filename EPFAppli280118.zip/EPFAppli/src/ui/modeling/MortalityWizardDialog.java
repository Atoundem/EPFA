package ui.modeling;

//package org.cgiar.cip.ilcym.modelbuilder.mortality.wizards;

import modelDesigner.Mortality;
import org.eclipse.jface.wizard.Wizard;

public class MortalityWizardDialog extends Wizard {

	public MortalityWizardDialog() {
		setWindowTitle("Mortality");
	}

	@Override
	public void addPages() {
		addPage(new MainPageWizardPage());
		addPage(new SeveralModelsWizardPage());
		addPage(new OneModelWizardPage1());
		addPage(new OneModelWizardPage2());
		addPage(new SelectedModelWizardPage());
	}

	@Override
	public boolean performFinish() {
		if(Mortality.saveModelSelected())
			return true;
		else
			return false;
	}

	@Override
	public boolean canFinish() {
		return true;
	}

	
}
